<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Etienne Phrabot Développeur passionné et curieux - Portfolio" />
  <meta name="keywords" content="Portfolio, MMI, Developpeur, étudiant, alternance, full-stack, Chambery" />
  <meta name="description" content="Je m’appelle Etienne, j’ai 19 ans et j’étudie à l’IUT de Chambéry dans la formation MMI (Métiers du Multimédia et de l’Internet). Depuis 2 annnées, j’ai découvert le développement web et depuis, j’essaie de découvrir tous ces préceptes !">
  @php wp_head() @endphp
</head>
